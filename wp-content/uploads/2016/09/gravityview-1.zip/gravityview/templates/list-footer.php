<?php
/**
 * Display below the entries loop when using a list layout
 *
 * @package GravityView
 * @subpackage GravityView/templates
 *
 * @global GravityView_View $this
 */
?>
<?php gravityview_footer(); ?>
</div>
<?php gravityview_after(); ?>
